setwd("C:/Users/himan/BDA/Project/Phase2/Updated_ML")

#Using library dplyr to use filter() that allows us to refine our results 
library(dplyr)

# Loading akas and transforming : 
akas_data <- read.csv("akas_data.tsv", sep = "\t", header = TRUE, na.strings = "\\N" )
akas_data <- akas_data[,c(1,3,4,5,8)]

# Loading basics and transforming :
basics_data <- read.csv("basics_data.tsv", sep = "\t", header = TRUE, na.strings = "\\N")
basics_data <- basics_data[,c(1,2,5,8,9)]

# Loading ratings and transforming :
ratings_data <- read.csv("ratings_data.tsv", sep = "\t", header = TRUE, na.strings = "\\N" )

# Merging :
ratings_akas <- merge(ratings_data, akas_data, by.x = "tconst", by.y = "titleId")
basics_ratings_akas <- merge(ratings_akas, basics_data, by.x = "tconst", by.y="tconst")

#Creating a copy of the data we have obtained after merging
copy_basics_ratings_akas <- basics_ratings_akas

copy_basics_ratings_akas <- filter(copy_basics_ratings_akas, copy_basics_ratings_akas$titleType != "tvEpisode")
copy_basics_ratings_akas <- filter(copy_basics_ratings_akas, copy_basics_ratings_akas$titleType != "tvMiniSeries")
copy_basics_ratings_akas <- filter(copy_basics_ratings_akas, copy_basics_ratings_akas$titleType != "tvSeries")
copy_basics_ratings_akas <- filter(copy_basics_ratings_akas, copy_basics_ratings_akas$titleType != "tvMovie")
copy_basics_ratings_akas <- filter(copy_basics_ratings_akas, copy_basics_ratings_akas$titleType != "tvSpecial")
copy_basics_ratings_akas <- filter(copy_basics_ratings_akas, copy_basics_ratings_akas$titleType != "tvShort")
copy_basics_ratings_akas <- filter(copy_basics_ratings_akas, copy_basics_ratings_akas$titleType != "video")
copy_basics_ratings_akas <- filter(copy_basics_ratings_akas, copy_basics_ratings_akas$titleType != "videoGame")

imdb_data <- copy_basics_ratings_akas

# IMDB Dataset :
imdb_data

# For Movie Lens Dataset: 
movielens_movies <- read.csv("movies.txt",sep = "\t", header = TRUE )
movielens_rating <- read.csv("ratings.txt",sep = "\t", header = TRUE )

movielens_rating <- movielens_rating %>% group_by(MovieID) %>% summarise_each(funs(mean))
movielens_rating <- movielens_rating[,c(1,3)]
movielens_movies <- movielens_movies[,c(1,2)]

movielens_data <- merge(movielens_movies, movielens_rating, by.x = "MovieID", by.y = "MovieID")
movielens_data <- movielens_data[,c(2,3)]

# Movie Lens Dataset :
movielens_data

# Merging two datasets :
final_data <- merge(imdb_data, movielens_data, by.x = "title", by.y = "Title", all.x = TRUE)

# Transformation of movie ratings :
trial <- final_data
trial$Ratings[is.na(trial$Ratings)] <- trial$averageRating
trial$averageRating <- (trial$averageRating + trial$Ratings)/2
trial <- trial[,c(1,2,3,4,5,6,7,8,9,10,11)]

# Final dataset :
final_data <- trial

# Creating a sample of data :
sample_data <- merge(imdb_data, movielens_data, by.x = "title", by.y = "Title")
sample_data$Ratings <- (sample_data$averageRating + sample_data$Ratings)/2
sample_data <- sample_data[,c(1,2,3,4,5,6,7,8,9,10,11)]

#writing sample data to a tsv file for loading in SQL:
write.table(sample_data,file="sample_data.tsv",quote = FALSE, sep="\t", col.names = NA)