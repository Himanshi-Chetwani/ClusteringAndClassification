setwd("C:/Users/himan/BDA/Project/Phase2/Updated_ML")
# Dataset :
sample_data
#Histogram of NumVotes
hist(sample_data$numVotes,xlab = "Number of Votes", ylab = "Frequency", main="Histogram of NumVotes")
#Histogram of Average Ratings
hist(sample_data$averageRating,xlab = "Average Ratings", ylab = "Frequency", main="Histogram of Average Rating")
#Correlation plot of all attributes
pairs(sample_data, main = "Correlation between all attributes")
