Group: Metadata

Programming Language: R, SQL

Installation and Usage :
Collection & Merging data: 
1. R: Install RStudio (Recommended) and load the R Script (filename.R)
2. Install the respective packages in the R script. 
	eg: install.packages("package_name")
		install.packages("dplyr")
	library(dplyr)	- used to perform preprocessing on data


Storing data on a DBMS :
1. SQL: Install MySQL Workbench (Recommended) and load the SQL Script (filename.sql)
2. Place the data file - "sample_data.txt" at the appropriate location of your MYSQL Workbench Server location.
3. Run the SQL script for the successful creation and installation of the database into DBMS.